<?php
  session_start();
  require 'components/db/index-query.php';
?>
<!DOCTYPE html>
<html>
  <?php
    require 'assets/headers/home-header.html';
  ?>
  <body>
    
    <?php
      require 'components/common/nav-bar.php';

      if (!isset($_SESSION['is_auth'])) require 'components/login.html';
      else require 'components/index-hub.php';
      
      require 'components/common/footer.php';
      require 'components/common/mobi-sect.html';
      require 'components/common/scroll-top-btn.html';
    ?>
  </body>
  <?php 
    require 'assets/js/scripts.html'; 
    require 'assets/js/admin-scripts.html';
  ?>
</html>
