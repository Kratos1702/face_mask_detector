<?php 
  session_start();
  require 'components/db/device-query.php';
?>
<!DOCTYPE html>
<html>
  <?php require 'assets/headers/device-header.html'; ?>
  <body>
    <?php require 'components/common/nav-bar.php'; ?>

    <section class="gallery4 mbr-gallery cid-svKU79SIEz mbr-fullscreen" id="gallery4-o">
      <div class="container">
        <div class="mbr-section-head">
          <h3
            class="mbr-section-title mbr-fonts-style align-center m-0 display-2 mb-5"
          >
            <strong><?php echo $place_name; ?> Data</strong>
          </h3>
        </div>
        <div class="row">
          <div class="col-lg-6 col-sm-8 mt-5"><div id="piechart"  class=""></div></div>        
          <div class="col-lg-6 col-sm-8 mt-5"><div id="piechart2"  class=""></div></div>
        </div>
      </div>
    </section>

    <?php
      require 'components/common/footer.php';
      require 'components/common/mobi-sect.html';
      require 'components/common/scroll-top-btn.html';
    ?>
  </body>
  <?php 
    require 'assets/js/scripts.html';
    require 'components/common/charts.php';
  ?>
</html>
