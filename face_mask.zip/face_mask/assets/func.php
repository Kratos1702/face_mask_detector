<?php
  function connect_db(){  
    // Legge dati dal file
    $db_data = parse_ini_file('src/config.ini');
    // Crea la connessione
    $conn = mysqLi_connect($db_data['server'], $db_data['username'], $db_data['password'], $db_data['database']);

    // Controlla la connessione
    if(!$conn) die ("Connection Terminated! by Die() function". mysqLi_connect_error());
    else return $conn;
  }

  function connect_db_admin(){  
    // Legge dati dal file
    $db_data = parse_ini_file('../../../src/config.ini');
    // Crea la connessione
    $conn = mysqLi_connect($db_data['server'], $db_data['username'], $db_data['password'], $db_data['database']);

    // Controlla la connessione
    if(!$conn) die ("Connection Terminated! by Die() function". mysqLi_connect_error());
    else return $conn;
  }

  function connect_db_admin_2(){  
    // Legge dati dal file
    $db_data = parse_ini_file('../../src/config.ini');
    // Crea la connessione
    $conn = mysqLi_connect($db_data['server'], $db_data['username'], $db_data['password'], $db_data['database']);

    // Controlla la connessione
    if(!$conn) die ("Connection Terminated! by Die() function". mysqLi_connect_error());
    else return $conn;
  }

  function send_query($sql){
    $conn = connect_db();
    $result = mysqli_query($conn, $sql) or die(mysqli_error($conn));
    return $result; // ^ Invia query
  }

  function send_query_admin($sql){
    $conn = connect_db_admin();
    // if (!mysqli_select_db($conn, 'face_mask')) die("Uh oh, couldn't select database");
    $result = mysqli_query($conn, $sql) or die(mysqli_error($conn));
    return $result; // Invia query
  }

  // ************** REMOVE ALSO FROM ALTERVISTA ***************

  function send_query_admin_2($sql){
    $conn = connect_db_admin_2();
    // if (!mysqli_select_db($conn, 'face_mask')) die("Uh oh, couldn't select database");
    $result = mysqli_query($conn, $sql) or die(mysqli_error($conn));
    return $result; // Invia query
  }

  function enc($id){
    return $id*5-3;
  }

  function denc($id){
    return ($id+3)/5;
  }
?>