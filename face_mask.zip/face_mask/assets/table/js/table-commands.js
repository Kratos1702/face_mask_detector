function on_click(mode, id) {
  let imei = document.getElementById("imei_td" + id).innerHTML;

  if (mode != 2) {
    let psw =
      "fe9a7e19cf6009810e739d52fe943e66baf2d4c91929c03e5ec3146278b3eb57";
    let pass_psw = localStorage["psw"] || 0;

    if (!pass_psw || encrypt(pass_psw) != psw) {
      request_psw(mode, imei);
    } else do_task(mode, imei);
  } else view_row(imei);
}

function request_psw(mode, imei) {
  console.log("enter");
  swal({
    content: {
      element: "input",
      attributes: {
        placeholder: "Inserisci password",
        type: "password",
      },
    },
  }).then((data) => {
    let psw =
      "fe9a7e19cf6009810e739d52fe943e66baf2d4c91929c03e5ec3146278b3eb57";
    if (encrypt(data) === psw) {
      localStorage["psw"] = data;
      do_task(mode, imei);
    }
  });
}

function do_task(mode, imei) {
  if (!mode) update_row(imei);
  else if (mode == "1") delete_row(imei);
}

function delete_row(imei) {
  swal("Sei sicuro di voler eliminare questo tablet?", {
    buttons: ["No", true],
  }).then((value) => {
    if (value) send_post(1, imei);
  });
}

function update_row(imei) {
  send_post(0, imei);
}

function view_row(imei) {
  send_post(2, imei);
}

function send_post(mode, imei) {
  document.getElementById("mode").value = mode;
  document.getElementById("imei").value = imei;
  document.getElementById("subbtn").click();
}
