<?php
  session_start();  
  require 'assets/func.php';
?>
<!DOCTYPE html>
<html>
  <?php
    require 'assets/headers/home-header.html';
    require 'assets/headers/table-header.html'; // Admin table header
  ?>
  <body>
    <?php
      require 'components/common/nav-bar.php';

      if ($_SESSION['is_admin']) require 'components/admin/admin-panel.html';
      
      require 'components/common/footer.php';
      require 'components/common/mobi-sect.html';
      require 'components/common/scroll-top-btn.html';
    ?>
  </body>
  <?php 
    require 'assets/js/scripts.html'; 
    require 'assets/js/admin-scripts.html';
  ?>
</html>
