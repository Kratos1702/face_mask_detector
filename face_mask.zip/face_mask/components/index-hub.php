<?php

  if ($_SESSION['is_admin']) { // Admin
    echo '
        <script>
            window.location.replace("admin.php");
        </script>
    ';
    // require 'admin/admin-panel.html';
  } elseif ($_SESSION['is_enabled'] & !$_SESSION['is_admin']) { // Enabled user
      require 'devices-list.php';
  } elseif (!$_SESSION['is_enabled'] & !$_SESSION['is_admin']) { // Disabled user
      require 'components/disabled.html';
  }
  
?>