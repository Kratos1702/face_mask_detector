<?php
  require 'assets/func.php';
  if (isset($_POST['email'])) {

    $sql = "SELECT * FROM User WHERE email = '".htmlentities($_POST['email'], ENT_QUOTES)."'AND psw = '".md5($_POST['psw'])."'"; // Login
    $result = send_query($sql); // Invia query

    if($result->num_rows == 1) 
    while($row = mysqli_fetch_array($result)) 
    {
      $_SESSION['is_auth'] = TRUE;
      $_SESSION['name'] = $row['name'];
      $_SESSION['surname'] = $row['surname'];
      $_SESSION['email'] = $row['email'];
      $_SESSION['tel'] = $row['n_tel'];
      $_SESSION['id_user'] = intval($row['id']);
      $_SESSION['is_admin'] = (intval($row['is_admin'])) ? TRUE : FALSE ;
      $_SESSION['is_enabled'] = (intval($row['is_enabled'])) ? TRUE : FALSE ;
    }
  }  
?>