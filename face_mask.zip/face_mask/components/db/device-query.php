<?php
  require 'assets/func.php';

  // Average query
  $sql = "SELECT 
          count(*) AS total,
          sum(case when is_mask = 1 then 1 else 0 end) AS mask,
          sum(case when is_mask = 0 then 1 else 0 end) AS no_mask,
          name_place
          FROM `Reports`, `Place`
          WHERE fk_place = ".denc($_GET['id']);
  
  $result = send_query($sql); 
  if($result->num_rows > 0) 
  while($row = mysqli_fetch_array($result)) {
    $ave_mask = $row['mask'];
    $ave_no_mask = $row['no_mask'];
    $ave_tot = $row['total'];
    $place_name = $row['name_place'];
  }
  
  // Actually in query
  $sql = 'SELECT 
          count(*) AS total,
          sum(case when is_mask = 1 then 1 else 0 end) AS mask,
          sum(case when is_mask = 0 then 1 else 0 end) AS no_mask
          FROM `Reports`
          WHERE fk_place = 1 AND Reports.date = "' .date("Y-m-d").'"
          AND TIMEDIFF(Reports.hour, "11:00:00") < "' .date("H:i:s"). '"';
  
  $result = send_query($sql);
  if($result->num_rows > 0) 
  while($row = mysqli_fetch_array($result)) {
    $in_mask = $row['mask'];
    $in_no_mask = $row['no_mask'];
    $in_tot = $row['total'];
  }  
?>