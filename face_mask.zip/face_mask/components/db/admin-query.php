<?php
    session_start();
    require '../../assets/func.php';

    if ($_SESSION['is_admin'] & isset($_POST['mode'])) {
        switch ($_POST['mode']) {
            case 0:
                $sql = "INSERT INTO `User` (`name`, `surname`, `n_tel`, `email`, `psw`) VALUES 
                ('".htmlentities($_POST['name'], ENT_QUOTES)."', '".htmlentities($_POST['surname'], ENT_QUOTES)."', '".htmlentities($_POST['tel'], ENT_QUOTES)."', '".htmlentities($_POST['email'], ENT_QUOTES)."', '".md5($_POST['psw'])."')";
                echo $sql;
                send_query_admin_2($sql); 
                break;
            case 1:
                $sql = "DELETE FROM `User` WHERE id=".htmlentities($_POST['user'], ENT_QUOTES);
                echo $sql; // CHECK HEREEEE ************** 
                send_query_admin_2($sql); 
                break;
            case 2:
                $sql = "INSERT INTO `Place` (`name_place`, `address`, `n_civic`, `fk_city`, `fk_user`) VALUES 
                ('".htmlentities($_POST['place_name'], ENT_QUOTES)."', '".htmlentities($_POST['address'], ENT_QUOTES)."', ".htmlentities($_POST['n_civic'], ENT_QUOTES).", ".htmlentities($_POST['city'], ENT_QUOTES).", ".htmlentities($_POST['user'], ENT_QUOTES).")";
                echo $sql;
                send_query_admin_2($sql); 
                break;
            case 3:
                $sql = "DELETE FROM `Place` WHERE id=".htmlentities($_POST['place'], ENT_QUOTES);
                echo $sql;
                send_query_admin_2($sql); 
                break;
            
            default:
                echo 'Mode Error';
                break;
        }
    }
    echo '
        <script>
            window.location.replace("../../index.php");
        </script>
    ';
?>