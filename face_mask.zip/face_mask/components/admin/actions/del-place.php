<?php require '../../../assets/func.php';?>
<form autocomplete="off" action="components/db/admin-query.php" method="POST">
  <div class="row">
    <div class="col">
      <select id="user_select" class="form-control" aria-placeholder="Owner" onchange="show_place()">
        <option selected disabled>User</option>
        <?php
          $sql = "SELECT id, name, surname, email FROM `User` WHERE id!=1 ORDER BY surname ASC";
          $result = send_query_admin($sql); // Invia query

          if($result->num_rows) 
          while($row = mysqli_fetch_array($result)) 
          {
            echo '
            <option value="'.$row["id"].'">'.$row["surname"].' '.$row["name"].'  -  '.$row["email"].'</option>
            ';
          }
        ?>
      </select>
    </div>
    <div class="col" id="place_select">
    
    </div>
  </div>
  <div class="row mt-3 ml-1">
    <button type="submit" class="btn btn-warning">
      Delete place <i class="fas fa-user-minus fa-sm ml-2"></i>
    </button>
  </div>
  <input type="number" name="mode" value="3" hidden />
</form>
