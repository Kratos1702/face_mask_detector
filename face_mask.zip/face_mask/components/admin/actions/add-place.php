<?php require '../../../assets/func.php';?>
<form autocomplete="off" action="components/db/admin-query.php" method="POST">
  <div class="row">
    <div class="col">
      <input type="text" class="form-control" placeholder="Place name" name="place_name"/>
    </div>
    <div class="col">
      <select class="form-control" aria-placeholder="Owner" name="user">
        <option selected disabled>Owner</option>
        <?php
          $sql = "SELECT id, email, name, surname FROM `User` WHERE id!=1 ORDER BY surname ASC";
          $result = send_query_admin($sql); // Invia query

          if($result->num_rows) 
          while($row = mysqli_fetch_array($result)) 
          {
            echo '
            <option value="'.$row["id"].'">'.$row["surname"].' '.$row["name"].'  -  '.$row["email"].'</option>
            ';
          }
        ?>
      </select>
    </div>
  </div>
  <div class="row mt-4">
    <div class="col">
      <select class="form-control" aria-placeholder="City" name="city">
        <option selected disabled>City</option>
        <?php
          $sql = "SELECT id, name_city AS name FROM `City` ORDER BY name ASC";
          $result = send_query_admin($sql); 

          if($result->num_rows) 
          while($row = mysqli_fetch_array($result)) 
          {
            echo '
            <option value="'.$row["id"].'">'.$row["name"].'</option>
            ';
          }
        ?>
      </select>
    </div>
    <div class="col">
      <input type="text" class="form-control" placeholder="Address" name="address"/>
    </div>
    <div class="col">
      <input type="number" class="form-control" placeholder="Civic number" name="n_civic"/>
    </div>
  </div>
  <div class="row mt-3 ml-1">
    <button type="submit" class="btn btn-warning">
      Add place <i class="fas fa-map-marker-alt fa-sm ml-2"></i>
    </button>
  </div>
  <input type="number" name="mode" value="2" hidden />
</form>
