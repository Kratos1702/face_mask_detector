<?php
  if (isset($_GET['id'])) {
    require '../../../assets/func.php';
?>
    <select class="form-control" aria-placeholder="Place" name="place">
    <option selected disabled>Place</option>
    <?php
      $sql = "SELECT id, name_place FROM `Place` WHERE fk_user=".intval(htmlentities($_GET['id'], ENT_QUOTES))." ORDER BY name_place ASC";
      $result = send_query_admin($sql); // Invia query

      if($result->num_rows) 
      while($row = mysqli_fetch_array($result)) 
      {
        echo '
        <option value="'.$row["id"].'">'.$row["name_place"].'</option>
        ';
      }
    ?>
  </select>
<?php
  }
?>