<section class="menu cid-s48OLK6784" once="menu" id="menu1-h">
  <nav class="navbar navbar-dropdown navbar-fixed-top navbar-expand-lg">
    <div class="container">
      <div class="navbar-brand">
        <span class="navbar-logo">
          <a href="index.php"
            ><img
              src="assets/images/mbr-121x86.png"
              alt="Face Mask Icon"
              style="height: 3.8rem"
          /></a>
        </span>
        <span class="navbar-caption-wrap"
          ><a class="navbar-caption text-black display-7" href="index.php"
            >Face Mask</a
          ></span
        >
      </div>
      <button
        class="navbar-toggler"
        type="button"
        data-toggle="collapse"
        data-target="#navbarSupportedContent"
        aria-controls="navbarNavAltMarkup"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <div class="hamburger">
          <span></span>
          <span></span>
          <span></span>
          <span></span>
        </div>
      </button>
      <?php if (@$_SESSION['is_auth']) { ?>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul
          class="navbar-nav nav-dropdown nav-right"
          data-app-modern-menu="true"
        >
          <li class="nav-item">
            <a
              class="nav-link link text-black display-4"
              href="components/db/logout.php"
            >
            Logout
            </a>
          </li>
          <li class="nav-item">
            <a
              class="nav-link link text-black display-4"
              href="contact.php"
            >
            Contact
            </a>
          </li>
          <li class="nav-item">
            <a
              class="nav-link link text-black display-4"
              href=""
            >
              <?php
                echo $_SESSION['name'].' '.$_SESSION['surname'];
              ?>
            </a>
            
          </li>
        </ul>
      </div>
      <?php } ?>
    </div>
  </nav>
</section>
