<?php
    if (isset($_POST['email'])) {
        $to = 'mesposito.blog@gmail.com';
        $subject = $_POST['subject'];

        $message = 'From '.$_POST['full_name'].', '.$_POST['tel'].',<br><br>';
        $message .= $_POST['msg'];

        // Always set content-type when sending HTML email
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

        // More headers
        $headers .= 'From: <'.$_POST['email'].'>' . "\r\n";

        mail($to,$subject,$message,$headers);
    }
?>