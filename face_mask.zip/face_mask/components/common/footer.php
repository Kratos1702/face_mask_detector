<section
  class="footer3 cid-s48P1Icc8J mbr-reveal"
  once="footers"
  id="footer3-n"
>
  <div class="container-fluid">
    <div class="media-container-row align-center mbr-white">
      <div class="row row-links">
        <ul class="foot-menu">
          <li class="foot-menu-item mbr-fonts-style display-7">
            <a href="index.php" class="text-black text-primary">Home</a>
          </li>
          <?php if (@$_SESSION['is_auth']) { ?>
          <li class="foot-menu-item mbr-fonts-style display-7">
            <a href="components/db/logout.php" class="text-black">Logout</a>
          </li>
          <?php } ?>
        </ul>
      </div>
      <div class="row social-row">
        <div class="social-list align-right pb-2">
          <div class="soc-item">
            <a href="mailto:mesposito.blog@gmail.com">
              <span
                class="mbr-iconfont mbr-iconfont-social socicon-mail socicon"
                style="color: rgb(53, 53, 53); fill: rgb(53, 53, 53)"
              ></span>
            </a>
          </div>
          <div class="soc-item">
            <a
              href="https://www.facebook.com/marcello.esposito.1276/"
              target="_blank"
            >
              <span
                class="mbr-iconfont mbr-iconfont-social socicon-facebook socicon"
                style="color: rgb(53, 53, 53); fill: rgb(53, 53, 53)"
              ></span>
            </a>
          </div>
          <div class="soc-item">
            <a
              href="https://www.instagram.com/marcello_esposito02/"
              target="_blank"
            >
              <span
                class="mbr-iconfont mbr-iconfont-social socicon-instagram socicon"
                style="color: rgb(53, 53, 53); fill: rgb(53, 53, 53)"
              ></span>
            </a>
          </div>
        </div>
      </div>
      <div class="row row-copirayt">
        <p
          class="mbr-text mb-0 mbr-fonts-style mbr-white align-center display-7"
        >
          © Copyright 2021 Marcello Esposito.
        </p>
      </div>
    </div>
  </div>
</section>
