<br /><br /><br /><br /><br /><br />
<section id="contact-form mbr-fullscreen">
  <div class="row justify-content-center myauto">
    <div class="col-lg-2 col-sm-8 bg-warning p-3">
      <h5><i class="fas fa-phone-alt fa-xs"></i> Let&apos;s talk</h5>
      <a href="tel:3666440855" class="text-dark">+39 366-644-0855</a>
      <br /><br />
      <h5><i class="fas fa-envelope fa-xs"></i> General support</h5>
      <a href="mailto:mesposito.blog@gmail.com" class="text-dark"
        >mesposito.blog@gmail.com</a
      >
    </div>
    <div class="col-lg-4 mt-ms-4">
      <form action="components/common/send_email.php" method="POST">
        <div class="row text-center"> 
          <div class="col">
            <input type="text" class="form-control" placeholder="Full name" name="full_name"
            <?php if ($_SESSION['is_auth']) echo 'value="'.$_SESSION['name'].' '.$_SESSION['surname'].'"' ?>/>
          </div>
          <div class="col">
            <input type="email" class="form-control" placeholder="Email"  name="email"
            <?php if ($_SESSION['is_auth']) echo 'value="'.$_SESSION['email'].'"' ?>/>
          </div>
        </div>
        <div class="row mt-4">
          <div class="col">
            <input type="tel" class="form-control" placeholder="Tel number" name="tel"
            <?php if ($_SESSION['is_auth']) echo 'value="'.$_SESSION['tel'].'"' ?>/>
          </div>
          <div class="col">
            <input type="tel" class="form-control" placeholder="Subject" name="subject"/>
          </div>
        </div>
        <div class="row mt-4">
          <div class="col">
            <textarea
              class="form-control"
              rows="3"
              placeholder="Insert your message here"
              name="msg"
            ></textarea>
          </div>
        </div>
        <div class="row mt-3 ml-1">
          <button type="submit" class="btn btn-warning">
            Send email <i class="fas fa-paper-plane fa-sm ml-2"></i>
          </button>
        </div>
        <input type="number" name="mode" value="0" hidden />
      </form>
    </div>
  </div>
</section>
