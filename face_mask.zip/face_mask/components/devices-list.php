<section class="features3 cid-svKP8Fq9bM mbr-fullscreen" id="features3-l">
  <div class="container">
    <div class="mbr-section-head">
      <h4 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2">
        <strong>Devices</strong>
      </h4>
    </div>
    <div class="row mt-4">
      <?php    
        $sql = "SELECT name_place, name_city, address, n_civic, Place.id AS id_place 
        FROM `Place`,`City` WHERE fk_user = ".htmlentities($_SESSION['id_user'], ENT_QUOTES)." AND fk_city = City.id"; 
        $result = send_query($sql); // Invia query
    
        if($result->num_rows > 0) 
        while($row = mysqli_fetch_array($result)) 
        {
          echo '
            <div class="item features-image сol-12 col-md-6 col-lg-4 active">
              <div class="item-wrapper">
                <div class="item-img">
                  <img src="assets/images/features1.jpg" data-slide-to="0" />
                </div>
                <div class="item-content">
                  <h5 class="item-title mbr-fonts-style display-7">
                    <strong>'.$row["name_place"].'</strong>
                  </h5>

                  <p class="mbr-text mbr-fonts-style mt-3 display-7"> St. '
                    .$row["address"]." ".$row['n_civic'].",<br>".$row['name_city'].
                  '</p>
                </div>
                <div class="mbr-section-btn item-footer mt-2">
                  <a
                    href="device.php?id='.enc($row['id_place']).'"
                    class="btn item-btn btn-warning display-4"
                    target=""
                    >View &gt;</a
                  >
                </div>
              </div>
            </div>
          ';
        }
      ?>
    </div>
  </div>
</section>
